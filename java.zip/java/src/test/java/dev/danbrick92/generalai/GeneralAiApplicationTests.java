package dev.danbrick92.generalai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeneralAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
